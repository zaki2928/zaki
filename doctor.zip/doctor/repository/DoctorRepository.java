package com.example.demo.doctor.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.doctor.entity.DoctorEntity;

public interface DoctorRepository extends CrudRepository<DoctorEntity, Integer>{
}