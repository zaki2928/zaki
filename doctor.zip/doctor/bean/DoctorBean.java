package com.example.demo.doctor.bean;

public class DoctorBean {
	private Integer idDoctor;
    private String doctorName;
	private Integer doctorAge;
	private Double doctorPhoneNO;
	private String doctorEmailId;
	
	 public DoctorBean() {
		 super ();
	 }
	
	public Integer getIdDoctor() {
		return idDoctor;
	}
	public void setIdDoctor(Integer idDoctor) {
		this.idDoctor = idDoctor;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public Integer getDoctorAge() {
		return doctorAge;
	}
	public void setDoctorAge(Integer doctorAge) {
		this.doctorAge = doctorAge;
	}

	public Double getDoctorPhoneNO() {
		return doctorPhoneNO;
	}
	public void setDoctorPhoneNO(Double doctorPhoneNO) {
		this.doctorPhoneNO = doctorPhoneNO;
	}
	public String getDoctorEmailId() {
		return doctorEmailId;
	}
	public void setDoctorEmailId(String doctorEmailId) {
		this.doctorEmailId = doctorEmailId;
	}
	
	}