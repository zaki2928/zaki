package com.example.demo.doctor.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.doctor.bean.DoctorBean;
import com.example.demo.doctor.entity.DoctorEntity;
import com.example.demo.doctor.repository.DoctorRepository;
import com.example.demo.doctor.service.DoctorService;




@Service
public  class DoctorServiceImpl implements DoctorService {

	@Autowired
	DoctorRepository docRepository;

	@Override
	public void createDoctorDetails(DoctorBean doctorBean) {
	DoctorEntity docEntity;
		if(doctorBean!=null)
		{
		docEntity = new DoctorEntity();
		BeanUtils.copyProperties(doctorBean, docEntity);
		docRepository.save(docEntity);
		}
	}
     @Override
     public void deleteDoctorDetails(Integer idDoctor) {
    	 if(idDoctor!=0)
    	 {
    	 docRepository.deleteById(idDoctor);
    	 }
     }
	@Override
	public List<DoctorBean> getAllDoctorDetails() {
		List<DoctorBean> listOfbean = new ArrayList<>();
		List<DoctorEntity> listOfentity = (List<DoctorEntity>) docRepository.findAll();
		if (listOfentity != null) {
			 for (DoctorEntity doctorEntity : listOfentity) {
				DoctorBean docBean = new DoctorBean();
				BeanUtils.copyProperties(doctorEntity, docBean);
				listOfbean.add(docBean);
			}
		}
		
		return listOfbean;
		
	}
	@Override
	public void updateDoctorDoctor(DoctorBean doctorbean) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public DoctorBean readDoctorDetails(Integer doctorID) {
		// TODO Auto-generated method stub
		return null;
	}

}