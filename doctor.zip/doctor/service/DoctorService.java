package com.example.demo.doctor.service;

import java.util.List;

import com.example.demo.doctor.bean.DoctorBean;



public interface DoctorService{
	public void createDoctorDetails(DoctorBean doctorBean);
	
	public void deleteDoctorDetails(Integer idDoctor);

	public List<DoctorBean> getAllDoctorDetails();

	public void updateDoctorDoctor(DoctorBean doctorbean);

	public DoctorBean readDoctorDetails(Integer doctorID);
}