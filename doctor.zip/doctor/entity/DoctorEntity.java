package com.example.demo.doctor.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name= "DOCTOR_DETAILS")

public class DoctorEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private Integer idDoctor;
	
	
	@Column(name="name")
	private String doctorName;
	@Column(name="Age")
	private Integer doctorAge;
	@Column(name="PhoneNO")
	private Double doctorPhoneNO;
	@Column(name="EmailId")
	private String doctorEmailId;
	
	public DoctorEntity() {
		super();
	}
	public Integer getIdDoctor() {
		return idDoctor;
	}
	public void setIdDoctor(Integer idDoctor) {
		this.idDoctor = idDoctor;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public Integer getDoctorAge() {
		return doctorAge;
	}
	public void setDoctorAge(Integer doctorAge) {
		this.doctorAge = doctorAge;
	}
	public Double getDoctorPhoneNO() {
		return doctorPhoneNO;
	}
	public void setDoctorPhoneNO(Double doctorPhoneNO) {
		this.doctorPhoneNO = doctorPhoneNO;
	}
	public String getDoctorEmailId() {
		return doctorEmailId;
	}
	public void setDoctorEmailId(String doctorEmailId) {
		this.doctorEmailId = doctorEmailId;
	}
	
}