package com.example.demo.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.doctor.bean.DoctorBean;
import com.example.demo.doctor.service.DoctorService;

@RestController
@RequestMapping("/Doctor")
@CrossOrigin("*")
public class DoctorController<Doctorbean> {
	
	@Autowired
	DoctorService docService;
	
	@RequestMapping(value="CreateDoctor",method = RequestMethod.POST)
	public void createDoctor(@RequestBody DoctorBean docBean)
	{
		if(docBean!=null) 
		{	
			docService.createDoctorDetails(docBean);
		}
	
	}
	@DeleteMapping  (value="/DeleteDoctor/{id}")
	  public void deleteDoctorDetails(@PathVariable("id") Integer idDoctor) 
		{
		docService.deleteDoctorDetails(idDoctor);
		}	
@PutMapping(value="/updateDoctor")
public void updateDoctorDetails(@RequestBody DoctorBean doctorbean)
{
	docService.updateDoctorDoctor(doctorbean);
}
@GetMapping(value="/getDoctorList")
public List<DoctorBean>  getListOfAllDoctorsDetails()
{
	return docService.getAllDoctorDetails();
}

}
